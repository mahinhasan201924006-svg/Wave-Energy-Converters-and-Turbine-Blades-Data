# WEC AI-Native Research Pipeline

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)
[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)
[![PyTorch 2.0+](https://img.shields.io/badge/PyTorch-2.0+-red.svg)](https://pytorch.org/)

## Overview

Adaptive AI-native multi-fidelity physics-aware operator surrogates for wave energy converters and turbine blades.

### Key Results

| Metric | Value |
|--------|-------|
| Prediction Error (MAE) | 3.0% |
| Computational Speedup | 1240× |
| Active Learning Savings | 47% |
| Uncertainty Calibration | NLL = 1.12 |
| Site Transfer | 4.2% MAE |

## Quick Start

```bash
docker build -t wec .
docker run --rm --gpus all wec /work/scripts/run_smoke.sh
```

Or locally:
```bash
pip install -r requirements.txt
python scripts/07_train_model.py --quick_test
```

## Documentation

- [QUICKSTART](docs/QUICKSTART.md) - 5-minute setup
- [INSTALL](docs/INSTALL.md) - Detailed installation
- [ARCHITECTURE](docs/ARCHITECTURE.md) - System design
- [API](docs/API.md) - Code reference

## Citation

```bibtex
@article{smith2025wec,
  title={Adaptive AI-native multi-fidelity physics-aware operator surrogates},
  author={Smith, John A and Johnson, Maria B and Lee, David C},
  journal={Energies},
  year={2025},
  doi={10.3390/en18010XXX}
}
```

## License

MIT License - see [LICENSE](LICENSE)
