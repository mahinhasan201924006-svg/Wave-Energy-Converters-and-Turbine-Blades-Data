#!/bin/bash
# Quick smoke test
echo "Running smoke test..."
python scripts/07_train_model.py --quick_test
echo "✅ Smoke test complete"
