#!/usr/bin/env python3
"""Generate publication-quality figures"""
import matplotlib.pyplot as plt

def fig1_pipeline():
    pass

def fig2_wave_spectra():
    pass

if __name__ == '__main__':
    print("Generating figures...")
