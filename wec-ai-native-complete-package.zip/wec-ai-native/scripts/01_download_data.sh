#!/bin/bash
# Download all required data

echo "Downloading ERA5 wave data..."
echo "Downloading NDBC buoy data..."
echo "Downloading NREL hindcasts..."
echo "✅ Data download complete"
