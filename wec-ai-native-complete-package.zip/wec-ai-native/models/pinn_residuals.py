"""Physics-Informed Neural Network loss"""
import torch
import torch.nn as nn

class PINNLoss(nn.Module):
    """Computes physics residuals for wave dynamics"""
    def __init__(self, rho=1025, mu=1e-3, weight=1.0):
        super().__init__()
        self.rho = rho
        self.mu = mu
        self.weight = weight
