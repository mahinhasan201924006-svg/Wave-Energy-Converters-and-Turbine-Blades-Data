"""Bayesian Gaussian Process for UQ"""
import torch
import torch.nn as nn

class BayesianEnsemble(nn.Module):
    """Ensemble of models for Bayesian uncertainty"""
    def __init__(self, base_model_fn, n_models=5):
        super().__init__()
        self.models = nn.ModuleList([base_model_fn() for _ in range(n_models)])
