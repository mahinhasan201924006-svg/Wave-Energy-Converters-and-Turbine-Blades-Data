"""Fourier Neural Operator backbone"""
import torch
import torch.nn as nn

class SpectralConv2d(nn.Module):
    """Spectral convolution in Fourier space"""
    def __init__(self, in_channels, out_channels, modes_x=64, modes_y=64):
        super().__init__()
        self.modes_x = modes_x
        self.modes_y = modes_y
        self.scale = 1 / (in_channels * out_channels)
        self.weights1 = nn.Parameter(
            self.scale * torch.randn(in_channels, out_channels, modes_x, modes_y, 2)
        )

class FNOBackbone(nn.Module):
    """Fourier Neural Operator network"""
    def __init__(self, modes=64, width=128, depth=4):
        super().__init__()
        self.fc0 = nn.Linear(3, width)
        self.layers = nn.ModuleList([
            SpectralConv2d(width, width, modes, modes) for _ in range(depth)
        ])
        self.fc1 = nn.Linear(width, 3)
