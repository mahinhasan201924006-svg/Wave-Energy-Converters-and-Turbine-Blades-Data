"""Complete hybrid model: FNO + Transformer + PINN"""
import torch
import torch.nn as nn
from .fno_backbone import FNOBackbone
from .transformer_encoder import TransformerEncoder
from .pinn_residuals import PINNLoss

class HybridModel(nn.Module):
    """Hybrid FNO-Transformer-PINN for WEC"""
    def __init__(self, modes=64, width=128, depth=4):
        super().__init__()
        self.fno = FNOBackbone(modes=modes, width=width, depth=depth)
        self.transformer = TransformerEncoder(hidden_dim=width)
        self.pinn_loss = PINNLoss(weight=0.1)
        self.power_head = nn.Sequential(
            nn.Linear(3 * 60 * 36, 256),
            nn.ReLU(),
            nn.Linear(256, 1)
        )
