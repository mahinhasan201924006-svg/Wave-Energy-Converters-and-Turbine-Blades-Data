# Contributing Guide

We welcome contributions!

## Process
1. Fork repository
2. Create feature branch
3. Make changes
4. Submit pull request

## Code Style
- Use Black for formatting
- Use type hints
- Write docstrings
- Add tests
