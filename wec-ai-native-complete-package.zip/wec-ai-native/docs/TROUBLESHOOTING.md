# Troubleshooting

## Common Issues

### CUDA not found
- Install NVIDIA drivers
- Install CUDA 11.8+
- Reinstall PyTorch with CUDA support

### Out of memory
- Reduce batch size in config
- Use gradient accumulation
- Use mixed precision (FP16)

## Getting Help
Open issue on GitHub or check docs/
