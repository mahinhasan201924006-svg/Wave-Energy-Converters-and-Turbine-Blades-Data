# Quick Start Guide

## 5-Minute Setup

### Prerequisites
- Python 3.10+
- CUDA 11.8 (optional)
- 50 GB disk space

### Option 1: Docker
```bash
git clone https://github.com/YOUR-ORG/wec-ai-native.git
cd wec-ai-native
docker build -t wec .
docker run --rm --gpus all -v $PWD:/work wec /work/scripts/run_smoke.sh
```

### Option 2: Local
```bash
pip install -r requirements.txt
python scripts/07_train_model.py --quick_test
```

### Option 3: Jupyter
```bash
jupyter lab notebooks/02_pipeline_demo.ipynb
```

## Next Steps
- Read [INSTALL.md](INSTALL.md)
- Check [ARCHITECTURE.md](ARCHITECTURE.md)
