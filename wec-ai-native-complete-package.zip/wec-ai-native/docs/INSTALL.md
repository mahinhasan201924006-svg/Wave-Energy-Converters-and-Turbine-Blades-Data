# Installation Guide

## Requirements
- Python 3.10+
- 16 GB RAM (32 GB recommended)
- NVIDIA GPU with CUDA 11.8+

## Installation

```bash
git clone https://github.com/YOUR-ORG/wec-ai-native.git
cd wec-ai-native
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
bash scripts/01_download_data.sh
```

## Troubleshooting
See [TROUBLESHOOTING.md](TROUBLESHOOTING.md)
