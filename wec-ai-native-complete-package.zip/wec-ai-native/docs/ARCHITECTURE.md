# System Architecture

## Overview
Adaptive AI-native multi-fidelity physics-aware operator surrogates

## Components

### FNO (Fourier Neural Operator)
- Input: 60×36 wave spectrum
- Modes: 64×64
- Output: 3-component field

### Transformer Encoder
- 10 time steps
- 2 layers, 8 heads
- 128-dim hidden

### PINN Loss
- Momentum equations
- Mass conservation
- Physics enforcement

## Training
1. RANS pretraining: 300 simulations
2. LES fine-tuning: 30 simulations
3. Active learning: uncertainty sampling
