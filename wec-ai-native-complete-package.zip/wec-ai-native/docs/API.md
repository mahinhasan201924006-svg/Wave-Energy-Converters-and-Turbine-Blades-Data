# API Reference

## Models

### HybridModel
```python
from models import HybridModel

model = HybridModel(modes=64, width=128)
power, uncertainty = model(x_spectrum, x_temporal)
```

## Data

### Loading Data
```python
from data import WECDataset
dataset = WECDataset('data/', split='train')
```

## Training
See `scripts/07_train_model.py` for examples.
