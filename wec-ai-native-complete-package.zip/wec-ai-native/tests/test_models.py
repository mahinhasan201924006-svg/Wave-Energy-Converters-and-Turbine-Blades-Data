"""Model tests"""
def test_hybrid_model():
    pass

def test_fno():
    pass
