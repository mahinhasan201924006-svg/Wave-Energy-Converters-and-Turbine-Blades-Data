# Data Directory

Raw data downloads go here. Use scripts/01_download_data.sh to populate.

Data sources:
- ERA5: https://cds.climate.copernicus.eu/
- NDBC: https://www.ndbc.noaa.gov/
- NREL: https://opendata.nrel.gov/
