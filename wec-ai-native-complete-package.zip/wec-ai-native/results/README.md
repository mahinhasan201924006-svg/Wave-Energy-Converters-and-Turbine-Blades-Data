# Results Directory

Training outputs:
- trained_models/ - Saved model checkpoints
- logs/ - TensorBoard logs
- figures/ - Generated plots
- metrics.csv - Evaluation metrics
