from setuptools import setup, find_packages

setup(
    name="wec-ai-native",
    version="1.0.0",
    description="Adaptive AI-native multi-fidelity physics-aware operator surrogates",
    author="John A. Smith, Maria B. Johnson, David C. Lee",
    url="https://github.com/YOUR-ORG/wec-ai-native",
    license="MIT",
    packages=find_packages(exclude=["tests"]),
    python_requires=">=3.10",
    install_requires=[
        "torch>=2.0.1",
        "pytorch-lightning>=2.0.9",
        "numpy>=1.24.0",
        "scipy>=1.10.0",
        "pandas>=2.0.0",
    ],
)
